# WEH · Cari Berita (ScrapingBee)

App simple untuk percubaan: masukkan topik → tarik hasil **Google sebenar** (organik + berita) guna **ScrapingBee Fast Search** → (pilihan) jadikan **draf artikel gaya WEH** dengan Gemini/Claude.

Kunci API duduk di **backend (Cloudflare)** — tiada kunci dalam HTML.

## Apa you perlu
- Akaun **Cloudflare** (free) + **Node.js**
- Kunci **ScrapingBee** — daftar di scrapingbee.com (ada 1,000 kredit free untuk cuba)
- (Pilihan) kunci **Gemini** (Google AI Studio) untuk butang "Jadikan artikel WEH"

## Jalan di laptop (local)
```bash
npm install
cp .dev.vars.example .dev.vars      # isi SCRAPINGBEE_API_KEY (+ GEMINI_API_KEY pilihan)
npm run dev                          # buka http://localhost:8788
```

## Deploy ke Cloudflare (live)
```bash
npx wrangler login
npx wrangler pages deploy public     # bagi nama projek, cth weh-cari → dapat URL .pages.dev
```
Kemudian di **Cloudflare → projek → Settings → Variables and Secrets** (jenis Secret):
```
SCRAPINGBEE_API_KEY = ...
GEMINI_API_KEY      = ...   (pilihan)
```
Save → auto re-deploy. Siap.

## Kos (percubaan)
- **ScrapingBee Fast Search** = light request, murah (~10 kredit/carian) — basic plan OK.
- "Jadikan artikel WEH" = 1 panggilan Gemini Flash (sangat murah) setiap draf.

## Struktur
```
public/index.html        UI simple (.weh)
functions/api/search.js  POST /api/search  → ScrapingBee Fast Search (MY)
functions/api/write.js   POST /api/write   → draf WEH (Gemini default / Claude)
.dev.vars.example        kunci API (rename → .dev.vars)
```

## Nota
- Tak boleh jalan dalam app Claude — perlu deploy / `wrangler pages dev` (kunci server-side).
- `country_code=my`, `language=ms`. Tukar dalam `functions/api/search.js` jika perlu.
- Ini app percubaan berasingan; boleh diserap ke OS.WEH penuh kemudian sebagai provider ScrapingBee.
