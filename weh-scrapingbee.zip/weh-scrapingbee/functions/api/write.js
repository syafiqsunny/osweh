/* POST /api/write {query, results} → draf artikel gaya WEH dari hasil carian.
   PILIHAN: hanya jalan jika GEMINI_API_KEY atau ANTHROPIC_API_KEY diset. Gemini default (murah). */
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { 'Content-Type': 'application/json', ...CORS } });
export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestPost({ request, env }) {
  let b; try { b = await request.json(); } catch { return J({ error: 'Bad JSON' }, 400); }
  const query = b.query || '';
  const results = Array.isArray(b.results) ? b.results : [];
  if (!results.length) return J({ error: 'Tiada hasil carian untuk dijana.' }, 400);
  const src = results.slice(0, 8).map((r, i) => `${i + 1}. ${r.title} — ${r.source} (${r.link})\n   ${r.snippet}`).join('\n');
  const prompt = `Anda editor WEH News (Malaysia). Tulis draf ringkas Bahasa Melayu gaya WEH berdasarkan hasil carian di bawah. Fakta dahulu; bezakan fakta vs dakwaan; atribusi + sumber; JANGAN reka fakta yang tiada dalam hasil; JANGAN guna markdown. Label HURUF BESAR di baris sendiri.

TOPIK: ${query}

HASIL CARIAN:
${src}

TAJUK
STANDFIRST
LEAD
ARTIKEL
[3-4 perenggan]
WEH, KENAPA PENTING?
SUMBER
[senarai pautan yang digunakan]
NOTA EDITOR
[apa yang perlu disahkan sebelum publish]`;

  try {
    if (env.GEMINI_API_KEY) {
      const u = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${env.GEMINI_API_KEY}`;
      const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { maxOutputTokens: 1500 } }) });
      const d = await r.json();
      if (!r.ok) throw new Error((d.error && d.error.message) || ('Gemini ' + r.status));
      const text = (d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts || []).map(p => p.text || '').join('').trim();
      return J({ text, model: 'gemini-2.5-flash' });
    }
    if (env.ANTHROPIC_API_KEY) {
      const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 1500, messages: [{ role: 'user', content: prompt }] }) });
      const d = await r.json();
      if (!r.ok) throw new Error((d.error && d.error.message) || ('Anthropic ' + r.status));
      const text = (d.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n').trim();
      return J({ text, model: 'claude-sonnet-4-6' });
    }
    return J({ error: 'Set GEMINI_API_KEY atau ANTHROPIC_API_KEY untuk jana artikel.' }, 501);
  } catch (e) { return J({ error: String((e && e.message) || e) }, 502); }
}
