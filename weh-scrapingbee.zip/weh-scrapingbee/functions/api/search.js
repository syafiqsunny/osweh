/* POST /api/search {query} → ScrapingBee Fast Search (Google organik + berita, Malaysia).
   Kunci dari env SCRAPINGBEE_API_KEY (server-side). Fast Search = ringan & murah (basic plan OK). */
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { 'Content-Type': 'application/json', ...CORS } });
export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestPost({ request, env }) {
  if (!env.SCRAPINGBEE_API_KEY) return J({ error: 'Belum set SCRAPINGBEE_API_KEY.' }, 501);
  let b; try { b = await request.json(); } catch { return J({ error: 'Bad JSON' }, 400); }
  const query = (b.query || '').trim();
  if (!query) return J({ error: 'Masukkan topik carian.' }, 400);

  const url = 'https://app.scrapingbee.com/api/v1/fast_search?' + new URLSearchParams({
    api_key: env.SCRAPINGBEE_API_KEY, search: query, country_code: 'my', language: 'ms'
  });
  try {
    const r = await fetch(url);
    const raw = await r.text();
    let data; try { data = JSON.parse(raw); } catch { return J({ error: 'ScrapingBee respons bukan JSON', raw: raw.slice(0, 300) }, 502); }
    if (!r.ok) return J({ error: (data && data.message) || ('ScrapingBee ' + r.status), detail: data }, 502);
    return J({ query, results: normalize(data) });
  } catch (e) { return J({ error: String((e && e.message) || e) }, 502); }
}

function normalize(d) {
  const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
  const pick = a => (Array.isArray(a) ? a : []).map(x => ({
    title: x.title || x.name || '', link: x.link || x.url || '',
    snippet: x.description || x.snippet || '', source: host(x.link || x.url), date: x.date || x.published_date || ''
  })).filter(x => x.title && x.link);
  let out = [];
  if (d.organic_results) out = out.concat(pick(d.organic_results));
  if (d.news_results) out = out.concat(pick(d.news_results));
  if (!out.length && Array.isArray(d)) out = pick(d);
  if (!out.length && Array.isArray(d.results)) out = pick(d.results);
  const seen = new Set();
  return out.filter(x => (seen.has(x.link) ? false : seen.add(x.link))).slice(0, 12);
}
