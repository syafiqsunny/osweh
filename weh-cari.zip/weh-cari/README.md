# WEH · Cari Berita — versi Cloudflare Worker

App simple: topik → hasil Google sebenar (ScrapingBee Fast Search) → (pilihan) draf artikel WEH (Gemini/Claude).
Versi ini deploy sebagai **Cloudflare Worker + static assets** (serasi dengan `npx wrangler deploy`).

## Struktur
```
wrangler.jsonc       config (assets=public, main=src/index.js)
src/index.js         Worker: /api/search, /api/write, + serve public/
public/index.html    UI (.weh)
.dev.vars.example    kunci API → rename .dev.vars untuk local
```

## Deploy (web, tanpa command) — lihat PANDUAN-PASANG.md

## Local (kalau nak)
```bash
npm install
cp .dev.vars.example .dev.vars   # isi SCRAPINGBEE_API_KEY (+ GEMINI_API_KEY pilihan)
npm run dev                       # http://localhost:8787
npm run deploy                    # ke Cloudflare
```

## Nota
- `name` dalam wrangler.jsonc = `weh-cari`. Kalau projek Cloudflare you nama lain, tukar ikut sama.
- Kunci API di env sahaja, bukan dalam kod.
