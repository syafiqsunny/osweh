# Panduan Pasang WEH · Cari (Cloudflare Worker, tanpa command)

GitHub (simpan fail) + Cloudflare (server). Free, klik sahaja. ~15 minit.

> ⚠️ Kunci API mesti di server (Cloudflare), JANGAN dalam fail GitHub.

## 0. Daftar (sekali)
- github.com (Sign up) · dash.cloudflare.com (Sign up)

## 1. Kunci ScrapingBee
- scrapingbee.com → Sign up (free, 1,000 kredit) → Dashboard → salin **API Key**.

## 2. Naik fail ke GitHub
1. Unzip `weh-cari.zip`. Folder ada: `public`, `src`, `wrangler.jsonc`, `package.json`, dll.
2. github.com → **+** → **New repository** → nama `weh-cari` → **Create repository**.
3. Klik **uploading an existing file**.
4. Seret isi DALAM folder (`public`, `src`, `wrangler.jsonc`, `package.json`...) ke kotak upload.
   > ⚠️ Seret **isi dalam** folder, bukan folder `weh-cari` itu sendiri. `wrangler.jsonc` & `src` mesti di paras atas repo.
5. **Commit changes**.

## 3. Sambung Cloudflare
1. dash.cloudflare.com → **Workers & Pages** → **Create**.
2. Tab **Workers** → **Connect to Git** (atau Import repository) → benarkan GitHub → pilih repo `weh-cari`.
3. Setup deploy:
   - **Deploy command:** `npx wrangler deploy`  (biasa dah default — biarkan)
   - **Build command:** kosongkan
4. **Save and Deploy** → tunggu ~1–2 minit → dapat URL `weh-cari.<akaun>.workers.dev`.

## 4. Masukkan kunci API
1. Projek `weh-cari` → **Settings** → **Variables and Secrets** → **Add**:
   - `SCRAPINGBEE_API_KEY` = kunci you · jenis **Secret** · Save
   - (pilihan) `GEMINI_API_KEY` = kunci Google AI Studio · Secret · Save
2. **Deployments** → deployment terkini → **⋯** → **Retry deployment** (apply kunci).

## 5. Siap
Buka URL `.workers.dev` → masukkan topik → **Cari**.

## Kalau ada masalah
- **"Could not detect a directory containing static files"** → `wrangler.jsonc` tiada di paras atas repo. Pastikan ia & folder `src` berada di root (Langkah 2.4).
- **"Belum set SCRAPINGBEE_API_KEY"** → kunci belum masuk / belum Retry deployment.
- **502 / carian kosong** → kunci salah atau kredit ScrapingBee habis.
- **Nama tak sepadan** → tukar `name` dalam wrangler.jsonc supaya sama dengan nama projek Cloudflare.
