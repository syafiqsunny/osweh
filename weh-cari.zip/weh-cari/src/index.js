/* OS.WEH · Cari (Worker + Static Assets)
   /api/search → ScrapingBee Fast Search   |   /api/write → draf WEH (Gemini/Claude)
   Lain-lain path → fail dalam public/ (index.html, dll). Kunci API dari env (Secret). */
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { 'Content-Type': 'application/json', ...CORS } });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS' && url.pathname.startsWith('/api/')) return new Response(null, { status: 204, headers: CORS });
    if (url.pathname === '/api/search') return handleSearch(request, env);
    if (url.pathname === '/api/write')  return handleWrite(request, env);
    return env.ASSETS.fetch(request);   // serve public/
  }
};

/* ---------- /api/search : ScrapingBee Fast Search (Malaysia) ---------- */
async function handleSearch(request, env) {
  if (!env.SCRAPINGBEE_API_KEY) return J({ error: 'Belum set SCRAPINGBEE_API_KEY.' }, 501);
  let b; try { b = await request.json(); } catch { return J({ error: 'Bad JSON' }, 400); }
  const query = (b.query || '').trim();
  if (!query) return J({ error: 'Masukkan topik carian.' }, 400);
  const url = 'https://app.scrapingbee.com/api/v1/fast_search?' + new URLSearchParams({
    api_key: env.SCRAPINGBEE_API_KEY, search: query, country_code: 'my', language: 'ms'
  });
  try {
    const r = await fetch(url);
    const raw = await r.text();
    let data; try { data = JSON.parse(raw); } catch { return J({ error: 'ScrapingBee respons bukan JSON', raw: raw.slice(0, 300) }, 502); }
    if (!r.ok) return J({ error: (data && data.message) || ('ScrapingBee ' + r.status), detail: data }, 502);
    return J({ query, results: normalize(data) });
  } catch (e) { return J({ error: String((e && e.message) || e) }, 502); }
}
function normalize(d) {
  const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
  const pick = a => (Array.isArray(a) ? a : []).map(x => ({
    title: x.title || x.name || '', link: x.link || x.url || '',
    snippet: x.description || x.snippet || '', source: host(x.link || x.url), date: x.date || x.published_date || ''
  })).filter(x => x.title && x.link);
  let out = [];
  if (d.organic_results) out = out.concat(pick(d.organic_results));
  if (d.news_results) out = out.concat(pick(d.news_results));
  if (!out.length && Array.isArray(d)) out = pick(d);
  if (!out.length && Array.isArray(d.results)) out = pick(d.results);
  const seen = new Set();
  return out.filter(x => (seen.has(x.link) ? false : seen.add(x.link))).slice(0, 12);
}

/* ---------- /api/write : draf gaya WEH (Gemini default / Claude) ---------- */
async function handleWrite(request, env) {
  let b; try { b = await request.json(); } catch { return J({ error: 'Bad JSON' }, 400); }
  const query = b.query || '';
  const results = Array.isArray(b.results) ? b.results : [];
  if (!results.length) return J({ error: 'Tiada hasil carian untuk dijana.' }, 400);
  const src = results.slice(0, 8).map((r, i) => `${i + 1}. ${r.title} — ${r.source} (${r.link})\n   ${r.snippet}`).join('\n');
  const prompt = `Anda editor WEH News (Malaysia). Tulis draf ringkas Bahasa Melayu gaya WEH berdasarkan hasil carian di bawah. Fakta dahulu; bezakan fakta vs dakwaan; atribusi + sumber; JANGAN reka fakta yang tiada dalam hasil; JANGAN guna markdown. Label HURUF BESAR di baris sendiri.

TOPIK: ${query}

HASIL CARIAN:
${src}

TAJUK
STANDFIRST
LEAD
ARTIKEL
[3-4 perenggan]
WEH, KENAPA PENTING?
SUMBER
[senarai pautan yang digunakan]
NOTA EDITOR
[apa yang perlu disahkan sebelum publish]`;
  try {
    if (env.GEMINI_API_KEY) {
      const u = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${env.GEMINI_API_KEY}`;
      const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { maxOutputTokens: 1500 } }) });
      const d = await r.json();
      if (!r.ok) throw new Error((d.error && d.error.message) || ('Gemini ' + r.status));
      const text = (d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts || []).map(p => p.text || '').join('').trim();
      return J({ text, model: 'gemini-2.5-flash' });
    }
    if (env.ANTHROPIC_API_KEY) {
      const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 1500, messages: [{ role: 'user', content: prompt }] }) });
      const d = await r.json();
      if (!r.ok) throw new Error((d.error && d.error.message) || ('Anthropic ' + r.status));
      const text = (d.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n').trim();
      return J({ text, model: 'claude-sonnet-4-6' });
    }
    return J({ error: 'Set GEMINI_API_KEY atau ANTHROPIC_API_KEY untuk jana artikel.' }, 501);
  } catch (e) { return J({ error: String((e && e.message) || e) }, 502); }
}
